package common.sql;

public interface ISQLValue {
	public String getSQLValue();
}
