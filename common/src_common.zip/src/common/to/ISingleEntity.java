package common.to;

//import entity.IEntityObject;

public interface ISingleEntity {
   // public IEntityObject getEntity();
}
