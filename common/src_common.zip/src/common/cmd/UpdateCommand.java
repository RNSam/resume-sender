package common.cmd;

public interface UpdateCommand extends DMLCommand {}
