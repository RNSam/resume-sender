package common.cmd;

public interface SelectCommand extends Command {}
