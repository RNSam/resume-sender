package common.cmd;

public interface InsertCommand extends DMLCommand {}