package common.cmd;

public interface DeleteCommand extends DMLCommand {}
